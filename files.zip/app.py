from flask import Flask, request, jsonify, render_template
from PIL import Image
import pytesseract
from deep_translator import GoogleTranslator
from gtts import gTTS
from pymongo import MongoClient
from datetime import datetime
import os
import base64
import uuid

app = Flask(__name__)

# Tesseract path
pytesseract.pytesseract.tesseract_cmd = r"C:\Users\INDIA\tesseract.exe"

# MongoDB connection
client = MongoClient("mongodb://localhost:27017/")
db = client["ocr_translator"]
history_col = db["translations"]

# Supported Indian languages
LANGUAGES = {
    "mr": "Marathi",
    "hi": "Hindi",
    "ta": "Tamil",
    "te": "Telugu",
    "kn": "Kannada",
    "gu": "Gujarati",
    "bn": "Bengali",
    "pa": "Punjabi",
}


@app.route("/")
def index():
    return render_template("index.html", languages=LANGUAGES)


@app.route("/translate", methods=["POST"])
def translate():
    if "image" not in request.files:
        return jsonify({"error": "No image uploaded"}), 400

    image_file = request.files["image"]
    target_lang = request.form.get("language", "mr")

    if target_lang not in LANGUAGES:
        return jsonify({"error": "Unsupported language"}), 400

    # Save image temporarily
    temp_path = f"temp_{uuid.uuid4().hex}.jpg"
    image_file.save(temp_path)

    try:
        # Step 1: OCR
        img = Image.open(temp_path)
        extracted_text = pytesseract.image_to_string(img).strip()

        if not extracted_text:
            return jsonify({"error": "No text found in image"}), 400

        # Step 2: Translate
        translated_text = GoogleTranslator(
            source="auto", target=target_lang
        ).translate(extracted_text)

        # Step 3: Text-to-Speech
        audio_filename = f"static/audio_{uuid.uuid4().hex}.mp3"
        tts = gTTS(text=translated_text, lang=target_lang)
        tts.save(audio_filename)

        # Step 4: Save to MongoDB
        record = {
            "extracted_text": extracted_text,
            "translated_text": translated_text,
            "target_language": LANGUAGES[target_lang],
            "lang_code": target_lang,
            "audio_file": audio_filename,
            "timestamp": datetime.utcnow(),
        }
        inserted = history_col.insert_one(record)

        return jsonify({
            "id": str(inserted.inserted_id),
            "extracted_text": extracted_text,
            "translated_text": translated_text,
            "language": LANGUAGES[target_lang],
            "audio_url": f"/{audio_filename}",
        })

    finally:
        if os.path.exists(temp_path):
            os.remove(temp_path)


@app.route("/history")
def history():
    records = list(history_col.find().sort("timestamp", -1).limit(10))
    for r in records:
        r["_id"] = str(r["_id"])
        r["timestamp"] = r["timestamp"].strftime("%d %b %Y, %I:%M %p")
    return jsonify(records)


if __name__ == "__main__":
    os.makedirs("static", exist_ok=True)
    app.run(debug=True)
